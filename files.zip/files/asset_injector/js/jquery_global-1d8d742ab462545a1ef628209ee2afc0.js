console.log('Cargando informacion al hacer clic dinamicamente');
jQuery(document).ready(function($) {
  $(document).on('click', 'input[name="field_profesor"]', function() {
    var selectedValue = $(this).val();
    
      var idbuscar = $(this).attr("id");
      var idusuario2 = jQuery('label[for="' + idbuscar + '"] > div.idusuario').html();
      var fecha_usar = $("input[id^='edit-field-fechas-laborables-value-min']").val();
      var partesFecha = fecha_usar.split('/'); // Divide la cadena en partes usando el separador '/'
			var fecha_formateada = partesFecha[2] + '-' + partesFecha[0].padStart(2, '0') + '-' + partesFecha[1].padStart(2, '0');


    var linkUrl = '/node/add/agendar_clase/agendando_clase?id=' + getLastParameterFromUrl() + '&field_profesor=' + idusuario2  + '&fecha='+fecha_formateada;
    $('#boton-agendamos-clase').attr('href', linkUrl);
  });

  function getLastParameterFromUrl() {
    var url = window.location.href;
    var urlSegments = url.split('/');
    var lastSegment = urlSegments[urlSegments.length - 1];
    var noultimo = urlSegments[urlSegments.length - 2];
    lastSegment = lastSegment +'&idcontenido='+noultimo;
    return lastSegment;
  }

  // Verificar si los radios ya están presentes al cargar la página
  if ($('input[name="field_profesor"]').length > 0) {
    // Activar el evento si los radios están presentes inicialmente
    $('input[name="field_profesor"]').on('click', function() {
      var selectedValue = $(this).val();
      var fecha_usar = $("input[id^='edit-field-fechas-laborables-value-min']").val();
      var partesFecha = fecha_usar.split('/'); // Divide la cadena en partes usando el separador '/'
			var fecha_formateada = partesFecha[2] + '-' + partesFecha[0].padStart(2, '0') + '-' + partesFecha[1].padStart(2, '0');      
      var linkUrl = '/agendar_cita?id=' + getLastParameterFromUrl() + '&field_profesor=' + selectedValue + '&fecha='+fecha_formateada;
      $('#boton-agendamos-clase').attr('href', linkUrl);
    });
  }
  
  
  
  // Ruta de la pagina
  // Obtener la ruta relativa
	var rutaRelativa = window.location.pathname;
	
	// Obtener los parámetros de la URL en un objeto
	var parametros = {};
	window.location.search.substr(1).split("&").forEach(function(item) {
	  var partes = item.split("=");
	  parametros[partes[0]] = decodeURIComponent(partes[1]);
	});
	
	// Acceder a los valores de los parámetros individuales
	var id = parametros.id;
	var idcontenido = parametros.idcontenido;
	var field_profesor = parametros.field_profesor;
	var fecha = parametros.fecha;
	
	// Imprimir los resultados en la consola
	console.log('Ruta Relativa: ', rutaRelativa);
	console.log('ID: ', id);
	console.log('ID Contenido: ', idcontenido);
	console.log('Field Profesor: ', field_profesor);
	console.log('Fecha: ', fecha);
	
	// Verificar si el input existe
	if ($('input[name="field_fecha_cita_oculta[0][value][date]"]').length) {
	  // Obtén la fecha en formato "2023-08-23"
	  var fechaOriginal = fecha;
	
	  // Divide la fecha en año, mes y día
	  var partesFecha = fechaOriginal.split('-');
	  var year = partesFecha[0];
	  var month = partesFecha[1];
	  var day = partesFecha[2];
	
	  // Formatea la fecha en el formato deseado "23/08/2023"
	  var fechaFormateada = year + '-' + month + '-' + day;
	
	  // Establece la fecha formateada como valor del input
	  $('input[name="field_fecha_cita_oculta[0][value][date]"]').val(fechaFormateada);
	  
	  
	  
	  
	  
	  var horaInicio = $('.views-field-field-fechas-laborables-value .field-content').text();
		var duracionMinutos = parseInt($('.views-field-field-fechas-laborables-duration .field-content').text());
		var horaFinal = $('.views-field-field-fechas-laborables-end-value .field-content').text();
		console.log("Hora de inicio: "+horaInicio + " Duracion: "+duracionMinutos + "Hora final: "+horaFinal)
		var horaInicioDate = new Date('2023-01-01 ' + horaInicio);
		var horaFinalDate = new Date('2023-01-01 ' + horaFinal);
		
		
		var intervaloMinutos = 30;
		var horariosDiv = $('#select-horario .horario');
		
		for (var tiempo = horaInicioDate; tiempo < horaFinalDate; tiempo.setMinutes(tiempo.getMinutes() + intervaloMinutos)) {
		  var hora = tiempo.getHours();
		  var minutos = tiempo.getMinutes();
		  var horaFormateada = ('0' + hora).slice(-2) + ':' + ('0' + minutos).slice(-2);
		
		  var enlace = $('<a>', {
		    href: '#',
		    text: horaFormateada,
		    class: 'mr-3 hora-enlace',
		    click: function() {
		      // Capturar el valor del enlace seleccionado
		      var horaSeleccionada = $(this).text() + ':00';
		      console.log(horaSeleccionada);
		      // Asignar el valor al campo de hora
		      $('input[name="field_fecha_cita_oculta[0][value][time]"]').val(horaSeleccionada);
		      
		      // Remover la clase "active" de todos los enlaces
		      $('a', horariosDiv).removeClass('active');
		      
		      // Agregar la clase "active" al enlace seleccionado
		      $(this).addClass('active');
		    }
		  });
		
		  horariosDiv.append(enlace);
		}
	}
	
});