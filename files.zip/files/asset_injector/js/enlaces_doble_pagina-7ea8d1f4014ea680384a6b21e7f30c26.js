  // Seleccionar los elementos con la clase .enlace .doble-clic
  var enlaces = document.querySelectorAll('.enlace .doble-clic');

  // Verificar si existen elementos
  if (enlaces.length > 0) {
    // Agregar evento de clic a cada enlace
    enlaces.forEach(function(enlace) {
      enlace.addEventListener('click', function(event) {
        event.preventDefault();
        
        var href = this.getAttribute('href');
        var data1 = this.getAttribute('data1');

        window.open(href, '_blank');
        window.location.href = window.location.origin + data1;
      });
    });
  }