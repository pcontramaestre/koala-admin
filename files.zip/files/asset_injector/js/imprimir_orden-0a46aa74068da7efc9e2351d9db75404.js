// Obtener el botón de imprimir
var botonImprimir = document.querySelector('.imprimir');

// Agregar un evento de clic al botón de imprimir
botonImprimir.addEventListener('click', function() {
  // Obtener el contenido del div con la clase ".informacion-orden"
  var contenido = document.querySelector('.informacion-orden').innerHTML;
  
  // Crear un elemento temporal para contener el contenido a imprimir
  var elementoTemporal = document.createElement('div');
  elementoTemporal.innerHTML = contenido;

  // Abrir la ventana de impresión y colocar el contenido a imprimir
  var ventanaImpresion = window.open('', '_blank');
  ventanaImpresion.document.write('<html><head><title>Impresión</title></head><body>' + elementoTemporal.innerHTML + '</body></html>');
  ventanaImpresion.document.close();
  ventanaImpresion.print();
});