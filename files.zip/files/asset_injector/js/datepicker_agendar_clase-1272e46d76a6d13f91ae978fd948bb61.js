(function ($) {
  // Se ejecuta cuando hay un evento ajax de una vista. Para que no se pierda el datepicker
    // Esta función se ejecutará cada vez que se complete una solicitud AJAX.
    // Puedes colocar aquí el código que deseas que se ejecute después de cada
    // actualización de la página o filtrado de vistas.
    // Por ejemplo, aquí puedes volver a inicializar un date picker u otros elementos.
    // Inicializar el Datepicker en el campo de entrada
    $("#datepicker-seleccionar-fecha").datepicker({
      inline: true, // Mostrar el Datepicker en línea
      dateFormat: "mm/dd/yy", // Formato de la fecha
      changeMonth: true, //Cambiar mes
      defaultDate: "+1D",
      minDate: "+1D",
      maxDate: "+1M +10D",
      onSelect: function (dateText) {
        var fechaInput = dateText;
        var fechaJS = new Date(fechaInput);
        // Sumamos un día a la fecha.
        fechaJS.setDate(fechaJS.getDate() + 1);
        // Obtenemos los componentes de la nueva fecha (mes, día, año).
        var nuevoMes = fechaJS.getMonth() + 1;
        var nuevoDia = fechaJS.getDate();
        var nuevoAnio = fechaJS.getFullYear();
        // Formateamos la nueva fecha al formato "mm/dd/yyyy".
        var nuevaFecha = nuevoMes + "/" + nuevoDia + "/" + nuevoAnio;
      	
        // Actualizar el valor del campo de entrada cuando se selecciona una fecha
        $("#datepicker-input").val(dateText);
        $("#edit-field-fechas-laborables-value-min").val(dateText);
        $("#edit-field-fechas-laborables-value-max").val(nuevaFecha);
        console.log("Seleccionado");
      },
    });

})(jQuery);


