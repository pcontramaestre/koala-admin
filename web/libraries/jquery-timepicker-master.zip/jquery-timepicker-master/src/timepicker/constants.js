const ONE_DAY = 86400;

export { ONE_DAY };
